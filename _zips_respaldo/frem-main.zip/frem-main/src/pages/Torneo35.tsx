import { useNavigate } from "react-router-dom";
import { ArrowLeft, Trophy, Users } from "lucide-react";
import ligaLogo from "@/assets/liga-frm-logo.png";
import amaysLogo from "@/assets/sponsors/amaysgroup.png";
import farmatoLanLogo from "@/assets/sponsors/farmatolan-green.jpeg";
import ResultsSection35 from "@/components/torneo35/ResultsSection35";
import StandingsSection35 from "@/components/torneo35/StandingsSection35";
import TopScorersSection35 from "@/components/torneo35/TopScorersSection35";
import UpcomingMatchesSection35 from "@/components/torneo35/UpcomingMatchesSection35";

// Team logos
import atleticoMarinoLogo from "@/assets/teams-35/atletico-marino.jpeg";
import atleticoSanIgnacioLogo from "@/assets/teams-35/atletico-san-ignacio.jpeg";
import coromotoFcLogo from "@/assets/teams-35/coromoto-fc.jpeg";
import fcCoromotoLogo from "@/assets/teams-35/fc-coromoto.jpeg";
import fenixLogo from "@/assets/teams-35/fenix.jpeg";
import frmLogo from "@/assets/teams-35/frm.jpeg";
import ingenierosLogo from "@/assets/teams-35/ingenieros.jpeg";
import jezreelLogo from "@/assets/teams-35/jezreel.jpeg";
import juniorLogo from "@/assets/teams-35/junior-de-la-canada.jpeg";
import theFamilyLogo from "@/assets/teams-35/the-family.jpeg";

const teams = [
  { name: "Atlético Mariño", logo: atleticoMarinoLogo },
  { name: "Atlético San Ignacio", logo: atleticoSanIgnacioLogo },
  { name: "Coromoto FC", logo: coromotoFcLogo },
  { name: "FC Coromoto", logo: fcCoromotoLogo },
  { name: "Fénix", logo: fenixLogo },
  { name: "Fundación Rogelio Montaño", logo: frmLogo },
  { name: "Ingenieros +35", logo: ingenierosLogo },
  { name: "Jezreel FC", logo: jezreelLogo },
  { name: "Junior de la Cañada", logo: juniorLogo },
  { name: "The Family +35", logo: theFamilyLogo },
];

const Torneo35 = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-primary/20 bg-background/90 backdrop-blur-xl">
        <div className="h-1 w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-500" />
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm font-medium hidden sm:inline">Torneos</span>
            </button>
            <div className="w-px h-8 bg-border/50 mx-2" />
            <img src={ligaLogo} alt="Liga FRM" className="h-10 w-auto object-contain" />
            <div className="hidden sm:block">
              <h1 className="font-display text-lg font-bold text-gradient-gold">Liga +35</h1>
              <p className="text-xs text-muted-foreground">Fútbol Amateur • Segunda Edición (Nocturna)</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#proximos" className="relative text-sm font-display uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors group">
              Próximos
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
            </a>
            <a href="#resultados" className="relative text-sm font-display uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors group">
              Resultados
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
            </a>
            <a href="#tabla" className="relative text-sm font-display uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors group">
              Tabla
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
            </a>
            <a href="#goleadores" className="relative text-sm font-display uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors group">
              Goleadores
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
            </a>
            <a href="#equipos" className="relative text-sm font-display uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors group">
              Equipos
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
            </a>
          </nav>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="relative bg-gradient-hero py-16 md:py-24 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-20 left-10 w-72 h-72 bg-emerald-500/20 rounded-full blur-[100px] animate-pulse" />
            <div className="absolute bottom-10 right-20 w-96 h-96 bg-teal-500/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }} />
          </div>

          <div className="container relative z-10 text-center max-w-4xl mx-auto">
            <div className="mb-8 animate-fade-in">
              <img
                src={ligaLogo}
                alt="Liga +35"
                className="h-24 md:h-32 mx-auto drop-shadow-2xl"
                style={{ filter: 'drop-shadow(0 0 30px hsl(var(--primary) / 0.4))' }}
              />
            </div>

            <div className="inline-flex items-center gap-2 bg-primary/20 border border-primary/40 rounded-full px-5 py-2 mb-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <Trophy className="w-5 h-5 text-primary animate-pulse" />
              <span className="font-display text-sm font-semibold tracking-widest text-primary uppercase">
                II Edición • Nocturna • 2025
              </span>
            </div>

            <h1 className="font-display text-5xl md:text-8xl font-bold mb-3 animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <span className="text-gradient-gold">Liga +35</span>
            </h1>
            <p className="text-2xl md:text-4xl text-foreground/90 font-display tracking-wider mb-2 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              Fútbol Amateur
            </p>
            <p className="text-lg text-muted-foreground animate-fade-in" style={{ animationDelay: '0.5s' }}>
              ⚽ Donde la pasión no tiene edad ⚽
            </p>

            {/* Stats */}
            <div className="mt-12 grid grid-cols-2 gap-4 max-w-md mx-auto">
              <div className="group bg-card/60 backdrop-blur-md border border-border/50 rounded-2xl p-5 hover:border-primary/50 hover:shadow-glow transition-all duration-300 animate-fade-in" style={{ animationDelay: '0.6s' }}>
                <Users className="w-8 h-8 text-primary mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <p className="text-3xl font-display font-bold text-gradient-gold">10</p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Equipos</p>
              </div>
              <div className="group bg-card/60 backdrop-blur-md border border-border/50 rounded-2xl p-5 hover:border-primary/50 hover:shadow-glow transition-all duration-300 animate-fade-in" style={{ animationDelay: '0.7s' }}>
                <Trophy className="w-8 h-8 text-primary mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <p className="text-3xl font-display font-bold text-gradient-gold">II</p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Edición</p>
              </div>
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent" />
        </section>

        {/* Teams */}
        <section id="equipos" className="py-16 md:py-24 bg-gradient-to-b from-card to-background">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block px-4 py-1.5 bg-primary/20 text-primary rounded-full text-sm font-medium mb-4 tracking-wider">
                SEGUNDA EDICIÓN (NOCTURNA)
              </span>
              <h2 className="text-3xl md:text-5xl font-display text-foreground mb-4">
                Equipos <span className="text-gradient-gold">Participantes</span>
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                10 equipos compiten por la gloria en la segunda edición nocturna de la Liga +35
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 md:gap-8">
              {teams.map((team, index) => (
                <div
                  key={team.name}
                  className="group relative flex flex-col items-center animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="relative w-full aspect-square bg-gradient-card rounded-xl border border-border/50 p-4 md:p-6 transition-all duration-300 group-hover:border-primary/50 group-hover:shadow-glow group-hover:-translate-y-2">
                    <div className="absolute inset-0 rounded-xl bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="relative w-full h-full flex items-center justify-center">
                      <img
                        src={team.logo}
                        alt={`Logo de ${team.name}`}
                        className="max-w-full max-h-full object-contain drop-shadow-lg transition-transform duration-300 group-hover:scale-110"
                        style={{ filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.3))' }}
                      />
                    </div>
                  </div>
                  <h3 className="mt-4 text-sm md:text-base font-medium text-center text-foreground/90 group-hover:text-primary transition-colors duration-300 line-clamp-2">
                    {team.name}
                  </h3>
                </div>
              ))}
            </div>

            <div className="mt-16 flex justify-center">
              <div className="h-1 w-32 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full" />
            </div>
          </div>
        </section>

        <UpcomingMatchesSection35 />
        <ResultsSection35 />
        <StandingsSection35 />
        <TopScorersSection35 />

        {/* Sponsors */}
        <section className="py-16 md:py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-background via-card/50 to-background pointer-events-none" />
          <div className="container relative mx-auto px-4 text-center">
            <span className="inline-block px-4 py-1.5 bg-primary/20 text-primary rounded-full text-sm font-medium mb-4 tracking-wider">
              NUESTROS ALIADOS
            </span>
            <h2 className="text-3xl md:text-5xl font-display text-foreground mb-8">
              Patrocinantes <span className="text-gradient-gold">Oficiales</span>
            </h2>
            <div className="flex items-center justify-center gap-6 md:gap-10 max-w-2xl mx-auto">
              <a href="https://amaysgroup.com" target="_blank" rel="noopener noreferrer" className="group block flex-1">
                <div className="bg-gradient-card rounded-2xl border border-border/50 p-8 transition-all duration-300 group-hover:border-primary/50 group-hover:shadow-glow">
                  <img
                    src={amaysLogo}
                    alt="Amays Group"
                    className="max-w-[200px] max-h-[100px] mx-auto object-contain group-hover:scale-105 transition-transform"
                  />
                  <p className="text-sm text-foreground/80 mt-4 group-hover:text-primary transition-colors">Amays Group</p>
                </div>
              </a>
              <a href="#" className="group block flex-1">
                <div className="bg-gradient-card rounded-2xl border border-border/50 p-8 transition-all duration-300 group-hover:border-primary/50 group-hover:shadow-glow">
                  <img
                    src={farmatoLanLogo}
                    alt="Farmacia Farmatolan"
                    className="max-w-[200px] max-h-[100px] mx-auto object-contain group-hover:scale-105 transition-transform"
                  />
                  <p className="text-sm text-foreground/80 mt-4 group-hover:text-primary transition-colors">Farmacia Farmatolan</p>
                </div>
              </a>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative border-t border-primary/20 bg-card/50 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none" />
        <div className="container relative py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">© 2025 Liga FRM. Todos los derechos reservados.</p>
            <button
              onClick={() => navigate("/")}
              className="text-sm text-primary hover:underline"
            >
              ← Volver a selección de torneos
            </button>
            <p className="text-sm text-muted-foreground">
              Diseñado por <span className="text-primary font-semibold">Amays Group</span>
            </p>
          </div>
        </div>
        <div className="h-1 w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-500" />
      </footer>
    </div>
  );
};

export default Torneo35;
