import React from "react";
import { Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

import atleticoMarinoLogo from "@/assets/teams-35/atletico-marino.jpeg";
import atleticoSanIgnacioLogo from "@/assets/teams-35/atletico-san-ignacio.jpeg";
import coromotoFcLogo from "@/assets/teams-35/coromoto-fc.jpeg";
import fcCoromotoLogo from "@/assets/teams-35/fc-coromoto.jpeg";
import fenixLogo from "@/assets/teams-35/fenix.jpeg";
import frmLogo from "@/assets/teams-35/frm.jpeg";
import ingenierosLogo from "@/assets/teams-35/ingenieros.jpeg";
import jezreelLogo from "@/assets/teams-35/jezreel.jpeg";
import juniorLogo from "@/assets/teams-35/junior-de-la-canada.jpeg";
import theFamilyLogo from "@/assets/teams-35/the-family.jpeg";

interface TeamStanding {
  position: number;
  name: string;
  logo: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
}

// Clasificación después de Jornada 9 (partidos jugados)
const standingsData: TeamStanding[] = [
  { position: 1, name: "Jezreel", logo: jezreelLogo, played: 9, won: 5, drawn: 3, lost: 1, goalsFor: 22, goalsAgainst: 15, goalDifference: 7, points: 18 },
  { position: 2, name: "Junior la Cañada", logo: juniorLogo, played: 8, won: 5, drawn: 2, lost: 1, goalsFor: 20, goalsAgainst: 5, goalDifference: 15, points: 17 },
  { position: 3, name: "FRM", logo: frmLogo, played: 8, won: 5, drawn: 2, lost: 1, goalsFor: 14, goalsAgainst: 6, goalDifference: 8, points: 17 },
  { position: 4, name: "Atl. Mariño", logo: atleticoMarinoLogo, played: 8, won: 4, drawn: 4, lost: 0, goalsFor: 18, goalsAgainst: 9, goalDifference: 9, points: 16 },
  { position: 5, name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, played: 9, won: 5, drawn: 0, lost: 4, goalsFor: 11, goalsAgainst: 14, goalDifference: -3, points: 15 },
  { position: 6, name: "The Family", logo: theFamilyLogo, played: 8, won: 4, drawn: 1, lost: 3, goalsFor: 15, goalsAgainst: 10, goalDifference: 5, points: 13 },
  { position: 7, name: "FC Coromoto", logo: fcCoromotoLogo, played: 9, won: 3, drawn: 1, lost: 5, goalsFor: 18, goalsAgainst: 15, goalDifference: 3, points: 10 },
  { position: 8, name: "Ingenieros", logo: ingenierosLogo, played: 9, won: 2, drawn: 1, lost: 6, goalsFor: 10, goalsAgainst: 24, goalDifference: -14, points: 7 },
  { position: 9, name: "Coromoto FC", logo: coromotoFcLogo, played: 9, won: 1, drawn: 1, lost: 7, goalsFor: 6, goalsAgainst: 17, goalDifference: -11, points: 4 },
  { position: 10, name: "Fénix", logo: fenixLogo, played: 9, won: 1, drawn: 1, lost: 7, goalsFor: 7, goalsAgainst: 26, goalDifference: -19, points: 4 },
];

const StandingsSection35 = () => {
  return (
    <section id="tabla" className="py-16 md:py-24 bg-background">
      <div className="container">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
            <Trophy className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Clasificación</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">Tabla de Posiciones</h2>
          <p className="text-muted-foreground mt-2">Clasificación general — Jornada 9 (partidos jugados)</p>
        </div>

        {/* Desktop */}
        <div className="max-w-4xl mx-auto hidden md:block">
          <div className="bg-gradient-card rounded-lg border border-border/50 overflow-hidden">
            <div className="bg-muted/50 border-b border-border/30">
              <div className="grid grid-cols-[40px_minmax(160px,1.5fr)_repeat(8,minmax(40px,1fr))] items-center gap-2 px-4 py-3">
                <span className="text-xs font-bold text-muted-foreground text-center">#</span>
                <span className="text-xs font-bold text-muted-foreground">Equipo</span>
                <span className="text-xs font-bold text-muted-foreground text-center">PJ</span>
                <span className="text-xs font-bold text-muted-foreground text-center">G</span>
                <span className="text-xs font-bold text-muted-foreground text-center">E</span>
                <span className="text-xs font-bold text-muted-foreground text-center">P</span>
                <span className="text-xs font-bold text-muted-foreground text-center">GF</span>
                <span className="text-xs font-bold text-muted-foreground text-center">GC</span>
                <span className="text-xs font-bold text-muted-foreground text-center">DG</span>
                <span className="text-xs font-bold text-primary text-center">PTS</span>
              </div>
            </div>
            <div className="divide-y divide-border/30">
              {standingsData.map((team, index) => (
                <div key={team.name} className={cn("grid grid-cols-[40px_minmax(160px,1.5fr)_repeat(8,minmax(40px,1fr))] items-center gap-2 px-4 py-3", "hover:bg-muted/30 transition-colors duration-200", "opacity-0 animate-fade-in", index < 3 && "bg-primary/5")} style={{ animationDelay: `${index * 50}ms` }}>
                  <span className={cn("w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold", index === 0 && "bg-yellow-500/20 text-yellow-500", index === 1 && "bg-gray-400/20 text-gray-400", index === 2 && "bg-amber-600/20 text-amber-600", index > 2 && "text-muted-foreground")}>{team.position}</span>
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center"><img src={team.logo} alt={team.name} className="max-w-full max-h-full object-contain" /></div>
                    <span className="font-semibold text-base truncate text-foreground">{team.name}</span>
                  </div>
                  <span className="text-sm text-muted-foreground text-center">{team.played}</span>
                  <span className="text-sm text-muted-foreground text-center">{team.won}</span>
                  <span className="text-sm text-muted-foreground text-center">{team.drawn}</span>
                  <span className="text-sm text-muted-foreground text-center">{team.lost}</span>
                  <span className="text-sm text-muted-foreground text-center">{team.goalsFor}</span>
                  <span className="text-sm text-muted-foreground text-center">{team.goalsAgainst}</span>
                  <span className={cn("text-sm text-center font-medium", team.goalDifference > 0 && "text-win", team.goalDifference < 0 && "text-destructive", team.goalDifference === 0 && "text-muted-foreground")}>{team.goalDifference > 0 ? `+${team.goalDifference}` : team.goalDifference}</span>
                  <span className="text-sm font-bold text-primary text-center">{team.points}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile */}
        <div className="md:hidden space-y-2 max-w-lg mx-auto">
          {standingsData.map((team, index) => (
            <div key={team.name} className={cn("bg-gradient-card rounded-lg border p-3", "opacity-0 animate-fade-in", "border-border/50", index < 3 && "border-primary/30")} style={{ animationDelay: `${index * 50}ms` }}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <span className={cn("w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0", index === 0 && "bg-yellow-500/20 text-yellow-500", index === 1 && "bg-gray-400/20 text-gray-400", index === 2 && "bg-amber-600/20 text-amber-600", index > 2 && "text-muted-foreground")}>{team.position}</span>
                  <div className="w-7 h-7 flex-shrink-0 flex items-center justify-center"><img src={team.logo} alt={team.name} className="max-w-full max-h-full object-contain" /></div>
                  <span className="font-semibold text-sm text-foreground">{team.name}</span>
                </div>
                <span className="text-lg font-bold text-primary">{team.points} pts</span>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                <div className="bg-muted/30 rounded px-1 py-1"><span className="text-muted-foreground block">PJ</span><span className="font-semibold text-foreground">{team.played}</span></div>
                <div className="bg-muted/30 rounded px-1 py-1"><span className="text-muted-foreground block">G/E/P</span><span className="font-semibold text-foreground">{team.won}/{team.drawn}/{team.lost}</span></div>
                <div className="bg-muted/30 rounded px-1 py-1"><span className="text-muted-foreground block">GF/GC</span><span className="font-semibold text-foreground">{team.goalsFor}/{team.goalsAgainst}</span></div>
                <div className="bg-muted/30 rounded px-1 py-1"><span className="text-muted-foreground block">DG</span><span className={cn("font-semibold", team.goalDifference > 0 && "text-win", team.goalDifference < 0 && "text-destructive", team.goalDifference === 0 && "text-muted-foreground")}>{team.goalDifference > 0 ? `+${team.goalDifference}` : team.goalDifference}</span></div>
              </div>
            </div>
          ))}
        </div>

        <div className="hidden md:flex flex-wrap items-center justify-center gap-4 mt-4 text-xs text-muted-foreground max-w-4xl mx-auto">
          <span><strong>PJ:</strong> Partidos Jugados</span><span><strong>G:</strong> Ganados</span><span><strong>E:</strong> Empatados</span><span><strong>P:</strong> Perdidos</span><span><strong>GF:</strong> Goles a Favor</span><span><strong>GC:</strong> Goles en Contra</span><span><strong>DG:</strong> Diferencia de Goles</span><span><strong>PTS:</strong> Puntos</span>
        </div>
      </div>
    </section>
  );
};

export default StandingsSection35;
