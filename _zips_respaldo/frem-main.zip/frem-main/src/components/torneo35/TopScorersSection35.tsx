import { Award } from "lucide-react";
import { cn } from "@/lib/utils";

// Goleadores acumulados después de Jornada 9
const scorersData = [
  { name: "Francisco Sánchez", team: "Junior la Cañada", goals: 6 },
  { name: "Francisco Hermoso", team: "Jezreel", goals: 6 },
  { name: "Tayron Flores", team: "Jezreel", goals: 7 },
  { name: "Johanni Nieves", team: "Junior la Cañada", goals: 5 },
  { name: "Luis Aponte", team: "FC Coromoto", goals: 4 },
  { name: "Dalvet Mora", team: "FC Coromoto", goals: 4 },
  { name: "Chris Lesmes", team: "FC Coromoto", goals: 2 },
  { name: "Yose Betancourt", team: "FC Coromoto", goals: 2 },
  { name: "Pedro Acosta", team: "FC Coromoto", goals: 1 },
  { name: "Randy Diaz", team: "Ingenieros", goals: 2 },
  { name: "Johan Pérez", team: "Atl. San Ignacio", goals: 2 },
  { name: "Y. Cabrera", team: "Jezreel", goals: 1 },
  { name: "Douglas Gómez", team: "Atl. Mariño", goals: 2 },
  { name: "José Araujo", team: "Fénix", goals: 4 },
  { name: "Jorge Márquez", team: "Junior la Cañada", goals: 3 },
  { name: "Jean Reyes", team: "FRM", goals: 3 },
  { name: "Javier Anzola", team: "Jezreel", goals: 3 },
  { name: "Hernán López", team: "Atl. Mariño", goals: 3 },
  { name: "Franco Arévalo", team: "Atl. Mariño", goals: 3 },
  { name: "Carlos Briceño", team: "Ingenieros", goals: 3 },
  { name: "Eduardo Cabrera", team: "Junior la Cañada", goals: 2 },
  { name: "Osmar Martinez", team: "Atl. Mariño", goals: 2 },
  { name: "David Parra", team: "FRM", goals: 3 },
  { name: "Castoromar León", team: "FRM", goals: 2 },
  { name: "Carlos Rojas", team: "FRM", goals: 2 },
  { name: "Alejandro Araujo", team: "Ingenieros", goals: 3 },
  { name: "José Ramírez", team: "The Family", goals: 2 },
  { name: "Y. Delgado", team: "Jezreel", goals: 2 },
  { name: "Adrian Bolivar", team: "FC Coromoto", goals: 2 },
  { name: "Breinner Bernal", team: "Coromoto FC", goals: 2 },
  { name: "Gregory Rodríguez", team: "Atl. San Ignacio", goals: 2 },
  { name: "Jesús Izarra", team: "The Family", goals: 2 },
  { name: "Jan González", team: "The Family", goals: 2 },
  { name: "Jose Montoya", team: "The Family", goals: 2 },
  { name: "Diego Roa", team: "Atl. San Ignacio", goals: 2 },
  { name: "Jahan Colmenares", team: "Atl. San Ignacio", goals: 1 },
  { name: "Luinger Lopez", team: "Atl. San Ignacio", goals: 1 },
  { name: "Junior Acosta", team: "Jezreel", goals: 1 },
  { name: "Daniel Castillo", team: "The Family", goals: 1 },
  { name: "Brayan Bello", team: "The Family", goals: 1 },
  { name: "Miguel Landaeta", team: "The Family", goals: 1 },
  { name: "José Delgado", team: "The Family", goals: 1 },
  { name: "Glenderson Quintero", team: "FRM", goals: 1 },
  { name: "Angel González", team: "FRM", goals: 1 },
  { name: "Rogelio", team: "FRM", goals: 1 },
  { name: "Jair Rivero", team: "FRM", goals: 1 },
  { name: "Jean Aure", team: "Junior la Cañada", goals: 1 },
  { name: "Jhonny Valdes", team: "Junior la Cañada", goals: 1 },
  { name: "Jeampiero Torres", team: "Junior la Cañada", goals: 1 },
  { name: "Robert Pimentel", team: "Junior la Cañada", goals: 1 },
  { name: "Jefferson Rojas", team: "Atl. Mariño", goals: 1 },
  { name: "Jackson Mijares", team: "Atl. Mariño", goals: 1 },
  { name: "Javier Villafras", team: "Atl. Mariño", goals: 1 },
  { name: "Jorge Rojas", team: "Atl. Mariño", goals: 1 },
  { name: "Carlos España", team: "Atl. Mariño", goals: 1 },
  { name: "Winder Garnique", team: "Atl. Mariño", goals: 2 },
  { name: "Carlos García", team: "FC Coromoto", goals: 1 },
  { name: "Elio Barrios", team: "Coromoto FC", goals: 1 },
  { name: "David Atehortua", team: "Coromoto FC", goals: 1 },
  { name: "Miguel Braidi", team: "Coromoto FC", goals: 1 },
  { name: "Dember Parra", team: "Fénix", goals: 1 },
  { name: "Gregory Hernández", team: "Fénix", goals: 1 },
  { name: "Miller Punchilupe", team: "Fénix", goals: 1 },
  { name: "Yesnei Soles", team: "Ingenieros", goals: 1 },
  { name: "Yorwin Sarmiento", team: "Ingenieros", goals: 1 },
  { name: "Carlos Perez", team: "Atl. San Ignacio", goals: 1 },
  { name: "Angel Cedeño", team: "Coromoto FC", goals: 1 },
  { name: "Lander Velasco", team: "Atl. San Ignacio", goals: 1 },
  { name: "Willy Gamez", team: "FC Coromoto", goals: 2 },
];

const TopScorersSection35 = () => {
  return (
    <section id="goleadores" className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
            <Award className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Goleadores</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">Tabla de Goleadores</h2>
          <p className="text-muted-foreground mt-2">Los máximos anotadores — Jornada 9</p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-gradient-card rounded-lg border border-border/50 overflow-hidden">
            <div className="grid grid-cols-12 gap-4 px-6 py-3 bg-muted/50 border-b border-border/30">
              <div className="col-span-1 text-xs font-semibold text-muted-foreground uppercase tracking-wider">#</div>
              <div className="col-span-5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Jugador</div>
              <div className="col-span-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Equipo</div>
              <div className="col-span-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider text-right">Goles</div>
            </div>

            {scorersData.map((scorer, index) => (
              <div key={index} className={cn("grid grid-cols-12 gap-4 px-6 py-4 items-center", "hover:bg-muted/30 transition-colors", "opacity-0 animate-fade-in", index !== scorersData.length - 1 && "border-b border-border/20")} style={{ animationDelay: `${index * 40 + 200}ms` }}>
                <div className="col-span-1">
                  {index < 3 ? (
                    <span className={cn("flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold", index === 0 && "bg-yellow-500/20 text-yellow-500", index === 1 && "bg-gray-400/20 text-gray-400", index === 2 && "bg-amber-600/20 text-amber-600")}>{index + 1}</span>
                  ) : (
                    <span className="text-sm text-muted-foreground font-medium">{index + 1}</span>
                  )}
                </div>
                <div className="col-span-5"><p className={cn("font-medium", index === 0 && "text-primary")}>{scorer.name}</p></div>
                <div className="col-span-4"><p className="text-sm text-muted-foreground">{scorer.team}</p></div>
                <div className="col-span-2 text-right"><span className={cn("font-display text-xl font-bold", index === 0 ? "text-primary" : "text-foreground")}>{scorer.goals}</span></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TopScorersSection35;
