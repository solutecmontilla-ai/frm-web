import { Trophy } from "lucide-react";
import MatchCard from "@/components/MatchCard";

import frmLogo from "@/assets/teams-35/frm.jpeg";
import fcCoromotoLogo from "@/assets/teams-35/fc-coromoto.jpeg";
import coromotoFcLogo from "@/assets/teams-35/coromoto-fc.jpeg";
import juniorLogo from "@/assets/teams-35/junior-de-la-canada.jpeg";
import atleticoMarinoLogo from "@/assets/teams-35/atletico-marino.jpeg";
import fenixLogo from "@/assets/teams-35/fenix.jpeg";
import atleticoSanIgnacioLogo from "@/assets/teams-35/atletico-san-ignacio.jpeg";
import theFamilyLogo from "@/assets/teams-35/the-family.jpeg";
import jezreelLogo from "@/assets/teams-35/jezreel.jpeg";
import ingenierosLogo from "@/assets/teams-35/ingenieros.jpeg";

type MatchData = {
  homeTeam: { name: string; logo: string; score: number; scorers: { name: string; goals: number }[] };
  awayTeam: { name: string; logo: string; score: number; scorers: { name: string; goals: number }[] };
  status?: "SUSPENDIDO";
};

const jornada1Data: MatchData[] = [
  { homeTeam: { name: "FRM", logo: frmLogo, score: 1, scorers: [{ name: "Carlos Rojas", goals: 1 }] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 1, scorers: [{ name: "Adrian Bolivar", goals: 1 }] } },
  { homeTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 1, scorers: [{ name: "Jean Aure", goals: 1 }] }, awayTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 1, scorers: [{ name: "Jefferson Rojas", goals: 1 }] } },
  { homeTeam: { name: "Fénix", logo: fenixLogo, score: 0, scorers: [] }, awayTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 1, scorers: [{ name: "Gregory Rodríguez", goals: 1 }] } },
  { homeTeam: { name: "The Family", logo: theFamilyLogo, score: 1, scorers: [{ name: "Daniel Castillo", goals: 1 }] }, awayTeam: { name: "Jezreel", logo: jezreelLogo, score: 3, scorers: [{ name: "Y. Delgado", goals: 1 }, { name: "Luis Guevara", goals: 1 }, { name: "Javier Anzola", goals: 1 }] } },
];

const jornada2Data: MatchData[] = [
  { homeTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 2, scorers: [{ name: "Jackson Mijares", goals: 1 }, { name: "Franco Arévalo", goals: 1 }] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 1, scorers: [{ name: "Adrian Bolivar", goals: 1 }] } },
  { homeTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 2, scorers: [{ name: "Johani Nieves", goals: 1 }, { name: "Jhonny Valdes", goals: 1 }] }, awayTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 0, scorers: [] } },
  { homeTeam: { name: "Fénix", logo: fenixLogo, score: 0, scorers: [] }, awayTeam: { name: "Jezreel", logo: jezreelLogo, score: 3, scorers: [{ name: "Tayron Flores", goals: 2 }, { name: "Y. Delgado", goals: 1 }] } },
  { homeTeam: { name: "The Family", logo: theFamilyLogo, score: 4, scorers: [{ name: "José Ramírez", goals: 2 }, { name: "José Montoya", goals: 1 }, { name: "Miguel Landaeta", goals: 1 }] }, awayTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 1, scorers: [{ name: "Yesnei Soles", goals: 1 }] } },
  { homeTeam: { name: "FRM", logo: frmLogo, score: 2, scorers: [{ name: "David Parra", goals: 1 }, { name: "Glenderson Quintero", goals: 1 }] }, awayTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 1, scorers: [{ name: "David Atehortua", goals: 1 }] } },
];

const jornada3Data: MatchData[] = [
  { homeTeam: { name: "The Family", logo: theFamilyLogo, score: 0, scorers: [] }, awayTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 1, scorers: [{ name: "Diego Roa", goals: 1 }] } },
  { homeTeam: { name: "Jezreel", logo: jezreelLogo, score: 2, scorers: [{ name: "Tayron Flores", goals: 2 }] }, awayTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 0, scorers: [] } },
  { homeTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 2, scorers: [{ name: "Javier Villafras", goals: 1 }, { name: "Jorge Rojas", goals: 1 }] }, awayTeam: { name: "Fénix", logo: fenixLogo, score: 2, scorers: [{ name: "Dember Parra", goals: 1 }, { name: "Gregory Hernández", goals: 1 }] } },
  { homeTeam: { name: "FRM", logo: frmLogo, score: 4, scorers: [{ name: "David Parra", goals: 1 }, { name: "Jean Reyes", goals: 1 }, { name: "Angel González", goals: 1 }, { name: "Rogelio", goals: 1 }] }, awayTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 1, scorers: [{ name: "Alejandro Araujo", goals: 1 }] } },
  { homeTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 4, scorers: [{ name: "Johanni Nieves", goals: 2 }, { name: "Jeampiero Torres", goals: 1 }, { name: "Robert Pimentel", goals: 1 }] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 1, scorers: [{ name: "Luis Aponte", goals: 1 }] } },
];

const jornada4Data: MatchData[] = [
  { homeTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 3, scorers: [{ name: "Carlos Briceño", goals: 2 }, { name: "Alejandro Araujo", goals: 1 }] }, awayTeam: { name: "Fénix", logo: fenixLogo, score: 1, scorers: [{ name: "Jose Araujo", goals: 1 }] } },
  { homeTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 1, scorers: [{ name: "Dalvet Mora", goals: 1 }] }, awayTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 2, scorers: [{ name: "Elio Barrios", goals: 1 }, { name: "Breinner Bernal", goals: 1 }] } },
  { homeTeam: { name: "Jezreel", logo: jezreelLogo, score: 0, scorers: [] }, awayTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 0, scorers: [] } },
  { homeTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 1, scorers: [{ name: "Jahan Colmenares", goals: 1 }] }, awayTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 5, scorers: [{ name: "Hernán López", goals: 3 }, { name: "Franco Arévalo", goals: 1 }, { name: "Carlos España", goals: 1 }] } },
  { homeTeam: { name: "FRM", logo: frmLogo, score: 1, scorers: [{ name: "Castoromar León", goals: 1 }] }, awayTeam: { name: "The Family", logo: theFamilyLogo, score: 2, scorers: [{ name: "Jesus Izarra", goals: 1 }, { name: "Jan González", goals: 1 }] } },
];

const jornada5Data: MatchData[] = [
  { homeTeam: { name: "The Family", logo: theFamilyLogo, score: 0, scorers: [] }, awayTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 1, scorers: [{ name: "Winder Garnique", goals: 1 }] } },
  { homeTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 1, scorers: [{ name: "Angel Cedeño", goals: 1 }] }, awayTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 2, scorers: [{ name: "Lander Velasco", goals: 1 }, { name: "Diego Roa", goals: 1 }] } },
  { homeTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 1, scorers: [{ name: "Luinger Lopez", goals: 1 }] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 0, scorers: [] } },
  { homeTeam: { name: "The Family", logo: theFamilyLogo, score: 1, scorers: [{ name: "Brayan Bello", goals: 1 }] }, awayTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 1, scorers: [{ name: "Breinner Bernal", goals: 1 }] } },
  { homeTeam: { name: "FRM", logo: frmLogo, score: 1, scorers: [{ name: "Castoromar León", goals: 1 }] }, awayTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 0, scorers: [] } },
  { homeTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 1, scorers: [{ name: "Yorwin Sarmiento", goals: 1 }] }, awayTeam: { name: "Jezreel", logo: jezreelLogo, score: 6, scorers: [{ name: "Francisco Hermoso", goals: 3 }, { name: "Javier Anzola", goals: 2 }, { name: "Junior Acosta", goals: 1 }] } },
];

const jornada6Data: MatchData[] = [
  { homeTeam: { name: "Fénix", logo: fenixLogo, score: 1, scorers: [{ name: "Jose Araujo", goals: 1 }] }, awayTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 5, scorers: [{ name: "Francisco Sánchez", goals: 3 }, { name: "Jorge Márquez", goals: 2 }] } },
  { homeTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 1, scorers: [{ name: "Carlos Briceño", goals: 1 }] }, awayTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 1, scorers: [{ name: "Winder Garnique", goals: 1 }] } },
  { homeTeam: { name: "Fénix", logo: fenixLogo, score: 1, scorers: [{ name: "José Araujo", goals: 1 }] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 5, scorers: [{ name: "Willy Gamez", goals: 2 }, { name: "Dalvet Mora", goals: 2 }, { name: "Luis Aponte", goals: 1 }] } },
  { homeTeam: { name: "FRM", logo: frmLogo, score: 1, scorers: [{ name: "David Parra", goals: 1 }] }, awayTeam: { name: "Jezreel", logo: jezreelLogo, score: 1, scorers: [{ name: "Francisco Hermoso", goals: 1 }] } },
  { homeTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 1, scorers: [{ name: "Alejandro Araujo", goals: 1 }] }, awayTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 0, scorers: [] } },
];

const jornada9Data: MatchData[] = [
  { homeTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 0, scorers: [] }, awayTeam: { name: "Fénix", logo: fenixLogo, score: 1, scorers: [{ name: "José Araujo", goals: 1 }] } },
  { homeTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 3, scorers: [{ name: "Douglas Gómez", goals: 2 }, { name: "J. Oviedo (e/p)", goals: 1 }] }, awayTeam: { name: "Jezreel", logo: jezreelLogo, score: 3, scorers: [{ name: "Tayron Flores", goals: 2 }, { name: "Luis Guevara", goals: 1 }] } },
  { homeTeam: { name: "Jezreel", logo: jezreelLogo, score: 1, scorers: [{ name: "Y. Cabrera", goals: 1 }] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 7, scorers: [{ name: "Chris Lesmes", goals: 2 }, { name: "Yose Betancourt", goals: 2 }, { name: "Luis Aponte", goals: 1 }, { name: "Pedro Acosta", goals: 1 }, { name: "Dalvert Mora", goals: 1 }] } },
  { homeTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 2, scorers: [{ name: "Randy Diaz", goals: 2 }] }, awayTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 3, scorers: [{ name: "Johan Pérez", goals: 2 }] } },
];

const jornada8Data: MatchData[] = [
  { homeTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 1, scorers: [{ name: "Miguel Braidi", goals: 1 }] }, awayTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 4, scorers: [{ name: "Johani Nieves", goals: 2 }, { name: "Eduardo Cabrera", goals: 2 }] } },
  { homeTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 0, scorers: [] }, awayTeam: { name: "FRM", logo: frmLogo, score: 1, scorers: [{ name: "Jean Reyes", goals: 1 }] } },
  { homeTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 0, scorers: [] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 1, scorers: [{ name: "Carlos García", goals: 1 }] } },
  { homeTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 0, scorers: [] }, awayTeam: { name: "Jezreel", logo: jezreelLogo, score: 0, scorers: [] }, status: "SUSPENDIDO" },
  { homeTeam: { name: "Jezreel", logo: jezreelLogo, score: 3, scorers: [{ name: "Francisco Hermoso", goals: 2 }, { name: "Tayron Flores", goals: 1 }] }, awayTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 2, scorers: [{ name: "Gregory Rodríguez", goals: 1 }, { name: "Carlos Perez", goals: 1 }] } },
  { homeTeam: { name: "Fénix", logo: fenixLogo, score: 1, scorers: [{ name: "Miller Punchilupe", goals: 1 }] }, awayTeam: { name: "The Family", logo: theFamilyLogo, score: 4, scorers: [{ name: "Jesús Izarra", goals: 1 }, { name: "José Delgado", goals: 1 }, { name: "Jan González", goals: 1 }, { name: "Jose Montoya", goals: 1 }] } },
];

const jornada7Data: MatchData[] = [
  { homeTeam: { name: "Jezreel", logo: jezreelLogo, score: 0, scorers: [] }, awayTeam: { name: "Atl. San Ignacio", logo: atleticoSanIgnacioLogo, score: 0, scorers: [] }, status: "SUSPENDIDO" },
  { homeTeam: { name: "Fénix", logo: fenixLogo, score: 0, scorers: [] }, awayTeam: { name: "FRM", logo: frmLogo, score: 3, scorers: [{ name: "Jean Reyes", goals: 1 }, { name: "Carlos Rojas", goals: 1 }, { name: "Jair Rivero", goals: 1 }] } },
  { homeTeam: { name: "Coromoto FC", logo: coromotoFcLogo, score: 0, scorers: [] }, awayTeam: { name: "Atl. Mariño", logo: atleticoMarinoLogo, score: 3, scorers: [{ name: "Osmar Martinez", goals: 2 }, { name: "Franco Arévalo", goals: 1 }] } },
  { homeTeam: { name: "Junior la Cañada", logo: juniorLogo, score: 4, scorers: [{ name: "Francisco Sánchez", goals: 3 }, { name: "Jorge Márquez", goals: 1 }] }, awayTeam: { name: "Ingenieros", logo: ingenierosLogo, score: 0, scorers: [] } },
  { homeTeam: { name: "The Family", logo: theFamilyLogo, score: 3, scorers: [] }, awayTeam: { name: "FC Coromoto", logo: fcCoromotoLogo, score: 1, scorers: [{ name: "Luis Aponte", goals: 1 }] } },
];

interface JornadaBlockProps {
  jornada: number;
  matches: MatchData[];
}

const JornadaBlock = ({ jornada, matches }: JornadaBlockProps) => (
  <div className="mb-12">
    <div className="flex items-center gap-3 mb-6">
      <div className="h-px flex-1 bg-border/50" />
      <h3 className="font-display text-lg font-bold text-primary uppercase tracking-wider">Jornada {jornada}</h3>
      <span className="text-xs text-muted-foreground bg-muted/50 rounded-full px-3 py-1">{matches.length} partidos</span>
      <div className="h-px flex-1 bg-border/50" />
    </div>
    <div className="space-y-4">
      {matches.map((match, index) => (
        <MatchCard key={index} homeTeam={match.homeTeam} awayTeam={match.awayTeam} delay={index} status={match.status} />
      ))}
    </div>
  </div>
);

const ResultsSection35 = () => {
  return (
    <section id="resultados" className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
            <Trophy className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Resultados</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">Resultados del Torneo</h2>
          <p className="text-muted-foreground mt-2">Cancha: La Trinidad</p>
        </div>
        <div className="max-w-3xl mx-auto">
          <JornadaBlock jornada={9} matches={jornada9Data} />
          <JornadaBlock jornada={8} matches={jornada8Data} />
          <JornadaBlock jornada={7} matches={jornada7Data} />
          <JornadaBlock jornada={6} matches={jornada6Data} />
          <JornadaBlock jornada={5} matches={jornada5Data} />
          <JornadaBlock jornada={4} matches={jornada4Data} />
          <JornadaBlock jornada={3} matches={jornada3Data} />
          <JornadaBlock jornada={2} matches={jornada2Data} />
          <JornadaBlock jornada={1} matches={jornada1Data} />
        </div>
      </div>
    </section>
  );
};

export default ResultsSection35;
