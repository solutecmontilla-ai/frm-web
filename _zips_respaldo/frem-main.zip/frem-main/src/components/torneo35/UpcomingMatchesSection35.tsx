import { Calendar, Clock, MapPin, Trophy, Swords } from "lucide-react";
import { cn } from "@/lib/utils";

import atleticoMarinoLogo from "@/assets/teams-35/atletico-marino.jpeg";
import atleticoSanIgnacioLogo from "@/assets/teams-35/atletico-san-ignacio.jpeg";
import coromotoFcLogo from "@/assets/teams-35/coromoto-fc.jpeg";
import fcCoromotoLogo from "@/assets/teams-35/fc-coromoto.jpeg";
import fenixLogo from "@/assets/teams-35/fenix.jpeg";
import frmLogo from "@/assets/teams-35/frm.jpeg";
import ingenierosLogo from "@/assets/teams-35/ingenieros.jpeg";
import jezreelLogo from "@/assets/teams-35/jezreel.jpeg";
import juniorLogo from "@/assets/teams-35/junior-de-la-canada.jpeg";
import theFamilyLogo from "@/assets/teams-35/the-family.jpeg";

interface MatchInfo {
  home: { name: string; logo: string };
  away: { name: string; logo: string };
  time: string;
}

interface MatchDay {
  day: string;
  venue: string;
  matches: MatchInfo[];
}

const schedule: MatchDay[] = [
  {
    day: "Viernes",
    venue: "La Trinidad",
    matches: [
      {
        home: { name: "FRM", logo: frmLogo },
        away: { name: "Atl. Mariño", logo: atleticoMarinoLogo },
        time: "7:00 PM",
      },
      {
        home: { name: "Junior la Cañada", logo: juniorLogo },
        away: { name: "The Family", logo: theFamilyLogo },
        time: "9:00 PM",
      },
    ],
  },
];

const MatchRow = ({ match, delay }: { match: MatchInfo; delay: number }) => (
  <div
    className={cn(
      "bg-gradient-card border border-border/50 rounded-lg p-4",
      "hover:border-primary/50 hover:shadow-glow transition-all duration-300",
      "opacity-0 animate-fade-in"
    )}
    style={{ animationDelay: `${delay}ms` }}
  >
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-2.5 flex-1 min-w-0">
        <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center">
          <img src={match.home.logo} alt={match.home.name} className="max-w-full max-h-full object-contain" />
        </div>
        <span className="font-semibold text-sm text-foreground truncate">{match.home.name}</span>
      </div>

      <div className="flex flex-col items-center gap-1 px-3">
        <Swords className="w-4 h-4 text-primary" />
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>{match.time}</span>
        </div>
      </div>

      <div className="flex items-center gap-2.5 flex-1 min-w-0 justify-end">
        <span className="font-semibold text-sm text-foreground truncate text-right">{match.away.name}</span>
        <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center">
          <img src={match.away.logo} alt={match.away.name} className="max-w-full max-h-full object-contain" />
        </div>
      </div>
    </div>
  </div>
);

const UpcomingMatchesSection35 = () => {
  let matchIndex = 0;

  return (
    <section id="proximos" className="py-16 md:py-24 bg-gradient-to-b from-background to-card">
      <div className="container">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
            <Calendar className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Próximos Partidos</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Jornada <span className="text-gradient-gold">#9</span>
          </h2>
          <p className="text-muted-foreground mt-2">Programación de la próxima fecha</p>
        </div>

        <div className="max-w-2xl mx-auto space-y-8">
          {schedule.map((day) => (
            <div key={day.day}>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center gap-2 bg-primary/10 rounded-full px-4 py-1.5">
                  <Calendar className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold text-primary">{day.day}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{day.venue}</span>
                </div>
              </div>
              <div className="space-y-3">
                {day.matches.map((match) => {
                  const currentIndex = matchIndex++;
                  return <MatchRow key={`${match.home.name}-${match.away.name}`} match={match} delay={currentIndex * 100} />;
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default UpcomingMatchesSection35;
