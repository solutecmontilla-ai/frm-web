import { Calendar, Clock, MapPin, Trophy, Swords } from "lucide-react";
import { cn } from "@/lib/utils";

import agapeLogo from "@/assets/teams/agape-fc.png";
import cimLogo from "@/assets/teams/cim.png";
import golazoLogo from "@/assets/teams/golazo-fc.png";
import realMaracayLogo from "@/assets/teams/real-maracay-fc.png";

interface MatchInfo {
  home: { name: string; logo: string };
  away: { name: string; logo: string };
  time: string;
}

interface MatchDay {
  day: string;
  venue: string;
  matches: MatchInfo[];
}

const schedule: MatchDay[] = [
  {
    day: "Sábado",
    venue: "La Trinidad",
    matches: [
      {
        home: { name: "Golazo", logo: golazoLogo },
        away: { name: "Casa Italia", logo: cimLogo },
        time: "3:30 PM",
      },
      {
        home: { name: "Real Maracay", logo: realMaracayLogo },
        away: { name: "Ágape", logo: agapeLogo },
        time: "5:30 PM",
      },
    ],
  },
];

const MatchRow = ({ match, delay }: { match: MatchInfo; delay: number }) => (
  <div
    className={cn(
      "bg-gradient-card border border-border/50 rounded-lg p-4",
      "hover:border-primary/50 hover:shadow-glow transition-all duration-300",
      "opacity-0 animate-fade-in"
    )}
    style={{ animationDelay: `${delay}ms` }}
  >
    <div className="flex items-center justify-between gap-3">
      {/* Home */}
      <div className="flex-1 flex flex-col items-center text-center">
        <div className="w-12 h-12 mb-1.5 flex items-center justify-center">
          <img src={match.home.logo} alt={match.home.name} className="max-w-full max-h-full object-contain" />
        </div>
        <span className="font-display text-xs md:text-sm font-bold text-foreground leading-tight">{match.home.name}</span>
      </div>

      {/* VS + Time */}
      <div className="flex flex-col items-center gap-1">
        <Swords className="w-4 h-4 text-primary" />
        <div className="flex items-center gap-1 text-primary">
          <Clock className="w-3 h-3" />
          <span className="text-xs font-semibold">{match.time}</span>
        </div>
      </div>

      {/* Away */}
      <div className="flex-1 flex flex-col items-center text-center">
        <div className="w-12 h-12 mb-1.5 flex items-center justify-center">
          <img src={match.away.logo} alt={match.away.name} className="max-w-full max-h-full object-contain" />
        </div>
        <span className="font-display text-xs md:text-sm font-bold text-foreground leading-tight">{match.away.name}</span>
      </div>
    </div>
  </div>
);

const UpcomingMatchesSection = () => {
  let globalDelay = 0;

  return (
    <section id="proxima-jornada" className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
            <Trophy className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Semifinales</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Programación Semifinales
          </h2>
          <p className="text-muted-foreground mt-2">
            Sábado en La Trinidad - 9na Edición
          </p>
        </div>

        <div className="max-w-2xl mx-auto space-y-8">
          {schedule.map((day, di) => (
            <div key={`${day.day}-${day.venue}`}>
              {/* Day header */}
              <div className="flex items-center gap-3 mb-3">
                <div className="flex items-center gap-2 bg-primary/10 rounded-full px-3 py-1">
                  <Calendar className="w-3.5 h-3.5 text-primary" />
                  <span className="text-sm font-bold text-primary">{day.day}</span>
                </div>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <MapPin className="w-3.5 h-3.5" />
                  <span className="text-sm">{day.venue}</span>
                </div>
                <div className="flex-1 h-px bg-border/50" />
              </div>

              {/* Matches */}
              <div className="space-y-3">
                {day.matches.map((match, mi) => {
                  const d = globalDelay;
                  globalDelay += 100;
                  return <MatchRow key={mi} match={match} delay={d} />;
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default UpcomingMatchesSection;
