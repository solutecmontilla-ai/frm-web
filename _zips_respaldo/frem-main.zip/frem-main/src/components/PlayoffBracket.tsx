import React from "react";
import { Trophy, Swords } from "lucide-react";
import { cn } from "@/lib/utils";

import ligaLogo from "@/assets/liga-frm-logo.png";
import realMaracayLogo from "@/assets/teams/real-maracay-fc.png";
import golazoLogo from "@/assets/teams/golazo-fc.png";
import pepitosLogo from "@/assets/teams/pepitos-el-point.png";
import sanIgnacioLogo from "@/assets/teams/san-ignacio-fc.png";
import agapeLogo from "@/assets/teams/agape-fc.png";
import cimLogo from "@/assets/teams/cim.png";
import chelseaLogo from "@/assets/teams/chelsea-fc.png";
import juventusLogo from "@/assets/teams/juventus-ng.png";

interface BracketTeam {
  name: string;
  logo: string;
  seed: number;
  score?: number;
}

interface BracketMatch {
  label: string;
  team1: BracketTeam;
  team2: BracketTeam;
  winner?: 1 | 2;
}

const quarterFinals: BracketMatch[] = [
  {
    label: "Llave A",
    team1: { name: "Real Maracay", logo: realMaracayLogo, seed: 1, score: 2 },
    team2: { name: "Juventus", logo: juventusLogo, seed: 8, score: 0 },
    winner: 1,
  },
  {
    label: "Llave D",
    team1: { name: "Consorcio", logo: sanIgnacioLogo, seed: 4, score: 0 },
    team2: { name: "Ágape", logo: agapeLogo, seed: 5, score: 1 },
    winner: 2,
  },
  {
    label: "Llave B",
    team1: { name: "Golazo", logo: golazoLogo, seed: 2, score: 1 },
    team2: { name: "Chelsea", logo: chelseaLogo, seed: 7, score: 0 },
    winner: 1,
  },
  {
    label: "Llave C",
    team1: { name: "Pepitos Point", logo: pepitosLogo, seed: 3, score: 0 },
    team2: { name: "Casa Italia", logo: cimLogo, seed: 6, score: 2 },
    winner: 2,
  },
];

const semiFinals: BracketMatch[] = [
  {
    label: "Semi 1",
    team1: { name: "Real Maracay", logo: realMaracayLogo, seed: 1 },
    team2: { name: "Ágape", logo: agapeLogo, seed: 5 },
  },
  {
    label: "Semi 2",
    team1: { name: "Golazo", logo: golazoLogo, seed: 2 },
    team2: { name: "Casa Italia", logo: cimLogo, seed: 6 },
  },
];

const MatchupCard = ({ match, side }: { match: BracketMatch; side: "left" | "right" }) => {
  const hasScore = match.team1.score !== undefined;
  return (
    <div
      className={cn(
        "bg-gradient-card border border-border/50 rounded-lg p-3 w-full",
        "hover:border-primary/50 transition-all duration-300 hover:shadow-glow",
        "opacity-0 animate-fade-in"
      )}
    >
      <div className="text-[10px] font-bold text-primary uppercase tracking-widest mb-2 text-center font-display">
        {match.label}
      </div>

      {/* Team 1 */}
      <div className={cn("flex items-center gap-2 mb-2", match.winner === 2 && "opacity-50")}>
        <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-[10px] font-bold flex items-center justify-center flex-shrink-0">
          {match.team1.seed}
        </span>
        <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center">
          <img src={match.team1.logo} alt={match.team1.name} className="max-w-full max-h-full object-contain" />
        </div>
        <span className={cn("font-semibold text-sm truncate", match.winner === 1 ? "text-win" : "text-foreground")}>{match.team1.name}</span>
        {hasScore && <span className={cn("ml-auto font-display text-lg font-bold", match.winner === 1 ? "text-win" : "text-muted-foreground")}>{match.team1.score}</span>}
      </div>

      {/* VS divider */}
      <div className="flex items-center gap-2 my-1.5">
        <div className="flex-1 h-px bg-border/50" />
        <Swords className="w-3.5 h-3.5 text-primary" />
        <div className="flex-1 h-px bg-border/50" />
      </div>

      {/* Team 2 */}
      <div className={cn("flex items-center gap-2", match.winner === 1 && "opacity-50")}>
        <span className="w-5 h-5 rounded-full bg-muted text-muted-foreground text-[10px] font-bold flex items-center justify-center flex-shrink-0">
          {match.team2.seed}
        </span>
        <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center">
          <img src={match.team2.logo} alt={match.team2.name} className="max-w-full max-h-full object-contain" />
        </div>
        <span className={cn("font-semibold text-sm truncate", match.winner === 2 ? "text-win" : "text-foreground")}>{match.team2.name}</span>
        {hasScore && <span className={cn("ml-auto font-display text-lg font-bold", match.winner === 2 ? "text-win" : "text-muted-foreground")}>{match.team2.score}</span>}
      </div>
    </div>
  );
};

const PlayoffBracket = () => {
  const leftQuarters = quarterFinals.slice(0, 2); // A & D
  const rightQuarters = quarterFinals.slice(2, 4); // B & C

  return (
    <section id="eliminatorias" className="py-16 md:py-24 bg-background">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
            <Trophy className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Fase Eliminatoria</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Cuartos de Final
          </h2>
          <p className="text-muted-foreground mt-2">
            Los 8 clasificados se enfrentan en eliminación directa
          </p>
        </div>

        {/* ====== DESKTOP BRACKET ====== */}
        <div className="hidden md:block max-w-5xl mx-auto">
          <div className="grid grid-cols-[1fr_auto_1fr] gap-6 items-center">
            {/* Left side: Llave A, Llave D + Semi 1 */}
            <div className="space-y-4">
              <div className="grid grid-cols-[1fr_auto] gap-4 items-center">
                <div className="space-y-4">
                  {leftQuarters.map((m, i) => (
                    <MatchupCard key={m.label} match={m} side="left" />
                  ))}
                </div>
                {/* Connector + Semi */}
                <div className="flex flex-col items-center gap-2">
                  <div className="w-px h-8 bg-primary/30" />
                  <MatchupCard match={semiFinals[0]} side="left" />
                  <div className="w-px h-8 bg-primary/30" />
                </div>
              </div>
            </div>

            {/* Center: Liga logo + Final placeholder */}
            <div className="flex flex-col items-center gap-4 px-4">
              <div className="w-24 h-24 rounded-full bg-gradient-card border-2 border-primary/50 flex items-center justify-center shadow-glow p-2">
                <img src={ligaLogo} alt="Liga FRM" className="max-w-full max-h-full object-contain" />
              </div>
              <div className="text-center">
                <div className="text-xs font-bold text-primary uppercase tracking-widest font-display">Final</div>
                <div className="text-xs text-muted-foreground italic mt-1">Por definir</div>
              </div>
              <Trophy className="w-8 h-8 text-primary animate-pulse-slow" />
            </div>

            {/* Right side: Llave B, Llave C + Semi 2 */}
            <div className="space-y-4">
              <div className="grid grid-cols-[auto_1fr] gap-4 items-center">
                {/* Connector + Semi */}
                <div className="flex flex-col items-center gap-2">
                  <div className="w-px h-8 bg-primary/30" />
                  <MatchupCard match={semiFinals[1]} side="right" />
                  <div className="w-px h-8 bg-primary/30" />
                </div>
                <div className="space-y-4">
                  {rightQuarters.map((m, i) => (
                    <MatchupCard key={m.label} match={m} side="right" />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ====== MOBILE BRACKET ====== */}
        <div className="md:hidden max-w-sm mx-auto space-y-6">
          {/* Liga logo centered */}
          <div className="flex flex-col items-center gap-2 mb-4">
            <div className="w-20 h-20 rounded-full bg-gradient-card border-2 border-primary/50 flex items-center justify-center shadow-glow p-2">
              <img src={ligaLogo} alt="Liga FRM" className="max-w-full max-h-full object-contain" />
            </div>
          </div>

          {/* Quarter-finals */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-primary uppercase tracking-widest text-center font-display">
              Cuartos de Final
            </h3>
            {quarterFinals.map((m) => (
              <MatchupCard key={m.label} match={m} side="left" />
            ))}
          </div>

          {/* Semi-finals */}
          <div className="space-y-3 pt-2">
            <h3 className="text-sm font-bold text-primary uppercase tracking-widest text-center font-display">
              Semifinales
            </h3>
            {semiFinals.map((s) => (
              <MatchupCard key={s.label} match={s} side="left" />
            ))}
          </div>

          {/* Final */}
          <div className="text-center pt-2">
            <h3 className="text-sm font-bold text-primary uppercase tracking-widest font-display">Final</h3>
            <div className="flex items-center justify-center gap-2 mt-2">
              <Trophy className="w-5 h-5 text-primary animate-pulse-slow" />
              <span className="text-xs text-muted-foreground italic">Por definir</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PlayoffBracket;
