import { Award } from "lucide-react";
import { cn } from "@/lib/utils";

// Goleadores después de Jornada 9 (acumulado, incluye J8 reprogramada)
const scorersData = [
  { name: "Erick Briceño", team: "Golazo", goals: 11 },
  { name: "Ramón Ruiz", team: "Real Maracay", goals: 8 },
  { name: "Joe Molina", team: "Casa Italia", goals: 6 },
  { name: "Deibi Infante", team: "Chelsea", goals: 6 },
  { name: "Francisco Salcedo", team: "Consorcio", goals: 5 },
  { name: "Joexander Tovar", team: "Aviación", goals: 5 },
  { name: "Freddy Manrique", team: "Juventus", goals: 5 },
  { name: "Luis Cohen", team: "Chelsea", goals: 5 },
  { name: "Jhonatan Flores", team: "Juventus", goals: 4 },
  { name: "Fernando Leal", team: "Casa Italia", goals: 4 },
  { name: "Pedro Cuellar", team: "Real Maracay", goals: 4 },
  { name: "Miguel Landaeta", team: "Pepitos Point", goals: 4 },
  { name: "Edinson Segovia", team: "Casa Italia", goals: 4 },
  { name: "Jackson Mijares", team: "Real Maracay", goals: 3 },
  { name: "Diamante Castro", team: "Golazo", goals: 3 },
  { name: "Pablo Bernal", team: "Pepitos Point", goals: 3 },
  { name: "Jesus García", team: "Golazo", goals: 3 },
  { name: "Wencer Gómez", team: "Ágape", goals: 3 },
  { name: "Andrés Parra", team: "Pepitos Point", goals: 3 },
  { name: "Osmel Franco", team: "Real Maracay", goals: 2 },
  { name: "Armando Serrano", team: "Golazo", goals: 2 },
  { name: "Rattia García", team: "Juventus", goals: 2 },
  { name: "Pablo Infante", team: "Chelsea", goals: 2 },
  { name: "Rainer Monagas", team: "Aviación", goals: 2 },
  { name: "Raúl Gómez", team: "Golazo", goals: 2 },
  { name: "Winder Aponte", team: "Consorcio", goals: 2 },
  { name: "Johnny Arreaza", team: "Aviación", goals: 2 },
];

const TopScorersSection = () => {
  return (
    <section id="goleadores" className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
            <Award className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Goleadores</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Tabla de Goleadores
          </h2>
          <p className="text-muted-foreground mt-2">
            Los máximos anotadores de la liga — Fase Eliminatoria
          </p>
        </div>

        {/* Scorers Table */}
        <div className="max-w-2xl mx-auto">
          <div className="bg-gradient-card rounded-lg border border-border/50 overflow-hidden">
            {/* Table Header */}
            <div className="grid grid-cols-12 gap-4 px-6 py-3 bg-muted/50 border-b border-border/30">
              <div className="col-span-1 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                #
              </div>
              <div className="col-span-5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Jugador
              </div>
              <div className="col-span-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Equipo
              </div>
              <div className="col-span-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider text-right">
                Goles
              </div>
            </div>

            {/* Table Body */}
            {scorersData.map((scorer, index) => (
              <div
                key={index}
                className={cn(
                  "grid grid-cols-12 gap-4 px-6 py-4 items-center",
                  "hover:bg-muted/30 transition-colors",
                  "opacity-0 animate-fade-in",
                  index !== scorersData.length - 1 && "border-b border-border/20"
                )}
                style={{ animationDelay: `${index * 100 + 300}ms` }}
              >
                <div className="col-span-1">
                  {index === 0 ? (
                    <span className="flex items-center justify-center w-6 h-6 bg-primary text-primary-foreground rounded-full text-xs font-bold">
                      {index + 1}
                    </span>
                  ) : (
                    <span className="text-sm text-muted-foreground font-medium">
                      {index + 1}
                    </span>
                  )}
                </div>
                <div className="col-span-5">
                  <p
                    className={cn(
                      "font-medium",
                      index === 0 && "text-primary"
                    )}
                  >
                    {scorer.name}
                  </p>
                </div>
                <div className="col-span-4">
                  <p className="text-sm text-muted-foreground">{scorer.team}</p>
                </div>
                <div className="col-span-2 text-right">
                  <span
                    className={cn(
                      "font-display text-xl font-bold",
                      index === 0 ? "text-primary" : "text-foreground"
                    )}
                  >
                    {scorer.goals}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TopScorersSection;
