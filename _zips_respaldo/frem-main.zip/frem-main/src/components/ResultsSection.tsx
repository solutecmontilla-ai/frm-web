import MatchCard from "./MatchCard";
import { Calendar } from "lucide-react";

import aviacionLogo from "@/assets/teams/aviacion-fc.png";
import frmLogo from "@/assets/teams/frm.png";
import pepitosLogo from "@/assets/teams/pepitos-el-point.png";
import golazoLogo from "@/assets/teams/golazo-fc.png";
import chelseaLogo from "@/assets/teams/chelsea-fc.png";
import realMaracayLogo from "@/assets/teams/real-maracay-fc.png";
import agapeLogo from "@/assets/teams/agape-fc.png";
import cimLogo from "@/assets/teams/cim.png";
import juventusLogo from "@/assets/teams/juventus-ng.png";
import sanIgnacioLogo from "@/assets/teams/san-ignacio-fc.png";

// Jornada 1
const jornada1Data = [
  {
    homeTeam: {
      name: "Pepitos Point",
      logo: pepitosLogo,
      score: 3,
      scorers: [
        { name: "Adam Salazar", goals: 1 },
        { name: "Pablo Bernal", goals: 1 },
        { name: "Orlando Galindo", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Aviación",
      logo: aviacionLogo,
      score: 2,
      scorers: [{ name: "Rainer Monagas", goals: 2 }],
    },
  },
  {
    homeTeam: {
      name: "FRM",
      logo: frmLogo,
      score: 1,
      scorers: [{ name: "Elvis Abreu", goals: 1 }],
    },
    awayTeam: {
      name: "Real Maracay",
      logo: realMaracayLogo,
      score: 5,
      scorers: [
        { name: "Ramón Ruiz", goals: 3 },
        { name: "David Atehortua", goals: 1 },
        { name: "Franzua Cardona", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Chelsea",
      logo: chelseaLogo,
      score: 3,
      scorers: [
        { name: "Pablo Infante", goals: 2 },
        { name: "Luis Cohen", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Golazo",
      logo: golazoLogo,
      score: 4,
      scorers: [
        { name: "Erick Briceño", goals: 2 },
        { name: "Diamante Castro", goals: 2 },
      ],
    },
  },
];

// Jornada 3
const jornada3Data = [
  {
    homeTeam: {
      name: "Casa Italia",
      logo: cimLogo,
      score: 3,
      scorers: [
        { name: "Fernando Leal", goals: 2 },
        { name: "Edgar González", goals: 1 },
      ],
    },
    awayTeam: {
      name: "FRM",
      logo: frmLogo,
      score: 1,
      scorers: [{ name: "Angel González", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "Pepitos Point",
      logo: pepitosLogo,
      score: 0,
      scorers: [],
    },
    awayTeam: {
      name: "Real Maracay",
      logo: realMaracayLogo,
      score: 3,
      scorers: [
        { name: "Ramón Ruiz", goals: 2 },
        { name: "Jhonny Acacio", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Aviación",
      logo: aviacionLogo,
      score: 1,
      scorers: [{ name: "Raúl Spallone", goals: 1 }],
    },
    awayTeam: {
      name: "Chelsea",
      logo: chelseaLogo,
      score: 2,
      scorers: [
        { name: "José Gómez", goals: 1 },
        { name: "Luis Cohen", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Ágape",
      logo: agapeLogo,
      score: 0,
      scorers: [],
    },
    awayTeam: {
      name: "Juventus",
      logo: juventusLogo,
      score: 2,
      scorers: [
        { name: "Jhonatan Flores", goals: 1 },
        { name: "Freddy Manrique", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Golazo",
      logo: golazoLogo,
      score: 3,
      scorers: [
        { name: "Raúl Gómez", goals: 1 },
        { name: "Erick Briceño", goals: 2 },
      ],
    },
    awayTeam: {
      name: "Consorcio",
      logo: sanIgnacioLogo,
      score: 2,
      scorers: [
        { name: "Javier Sánchez", goals: 1 },
        { name: "Lisandro Chirinos", goals: 1 },
      ],
    },
  },
];

// Jornada 7
const jornada7Data = [
  {
    homeTeam: { name: "Pepitos Point", logo: pepitosLogo, score: 2, scorers: [{ name: "Keni Novel", goals: 1 }, { name: "Isay Azuaje", goals: 1 }] },
    awayTeam: { name: "Casa Italia", logo: cimLogo, score: 0, scorers: [] },
  },
  {
    homeTeam: { name: "Real Maracay", logo: realMaracayLogo, score: 0, scorers: [] },
    awayTeam: { name: "Consorcio", logo: sanIgnacioLogo, score: 0, scorers: [] },
  },
  {
    homeTeam: { name: "FRM", logo: frmLogo, score: 2, scorers: [{ name: "Carlos Moreno", goals: 1 }, { name: "Rogelio", goals: 1 }] },
    awayTeam: { name: "Aviación", logo: aviacionLogo, score: 3, scorers: [{ name: "Joexander Tovar", goals: 2 }, { name: "Freddy Campero", goals: 1 }] },
  },
  {
    homeTeam: { name: "Golazo", logo: golazoLogo, score: 5, scorers: [{ name: "Erick Briceño", goals: 2 }, { name: "Armando Serrano", goals: 1 }, { name: "Luis Rodríguez", goals: 1 }, { name: "Jesus García", goals: 1 }] },
    awayTeam: { name: "Ágape", logo: agapeLogo, score: 0, scorers: [] },
  },
  {
    homeTeam: { name: "Chelsea", logo: chelseaLogo, score: 3, scorers: [{ name: "Luis Cohen", goals: 3 }] },
    awayTeam: { name: "Juventus", logo: juventusLogo, score: 1, scorers: [{ name: "Jonathan Flores", goals: 1 }] },
  },
];

// Jornada 6
const jornada6Data = [
  {
    homeTeam: { name: "Casa Italia", logo: cimLogo, score: 1, scorers: [{ name: "Esteban Nardulli", goals: 1 }] },
    awayTeam: { name: "Aviación", logo: aviacionLogo, score: 4, scorers: [{ name: "Johnny Arreaza", goals: 2 }, { name: "Joexander Tovar", goals: 1 }, { name: "Carlos Ruiz", goals: 1 }] },
  },
  {
    homeTeam: { name: "Consorcio", logo: sanIgnacioLogo, score: 5, scorers: [{ name: "Winder Aponte", goals: 2 }, { name: "Willian Rodríguez", goals: 1 }, { name: "Silvestre Lipetri", goals: 1 }, { name: "Francisco Salcedo", goals: 1 }] },
    awayTeam: { name: "Chelsea", logo: chelseaLogo, score: 2, scorers: [{ name: "Miguel Garcia", goals: 1 }, { name: "Jolfred Alexander", goals: 1 }] },
  },
  {
    homeTeam: { name: "FRM", logo: frmLogo, score: 0, scorers: [] },
    awayTeam: { name: "Golazo", logo: golazoLogo, score: 2, scorers: [{ name: "Jesus García", goals: 2 }] },
  },
  {
    homeTeam: { name: "Real Maracay", logo: realMaracayLogo, score: 2, scorers: [{ name: "Pedro Cuellar", goals: 1 }, { name: "Cristofer Mendoza", goals: 1 }] },
    awayTeam: { name: "Ágape", logo: agapeLogo, score: 0, scorers: [] },
  },
  {
    homeTeam: { name: "Pepitos Point", logo: pepitosLogo, score: 2, scorers: [{ name: "Andrés Parra", goals: 1 }, { name: "Richard Diaz", goals: 1 }] },
    awayTeam: { name: "Juventus", logo: juventusLogo, score: 0, scorers: [] },
  },
];

// Jornada Pendiente (Reprogramada)
const jornadaPendienteData = [
  {
    homeTeam: {
      name: "Casa Italia",
      logo: cimLogo,
      score: 4,
      scorers: [
        { name: "Edinson Segovia", goals: 2 },
        { name: "Jose Schillaci", goals: 1 },
        { name: "Fernando Leal", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Juventus",
      logo: juventusLogo,
      score: 1,
      scorers: [{ name: "Jonathan Flores", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "Ágape",
      logo: agapeLogo,
      score: 1,
      scorers: [{ name: "Wilman Ramos", goals: 1 }],
    },
    awayTeam: {
      name: "Consorcio",
      logo: sanIgnacioLogo,
      score: 0,
      scorers: [],
    },
  },
];

// Jornada 5
const jornada5Data = [
  {
    homeTeam: { name: "Consorcio", logo: sanIgnacioLogo, score: 3, scorers: [{ name: "Francisco Salcedo", goals: 3 }] },
    awayTeam: { name: "Casa Italia", logo: cimLogo, score: 3, scorers: [{ name: "Joe Molina", goals: 2 }, { name: "Edgar González", goals: 1 }] },
  },
  {
    homeTeam: { name: "Juventus", logo: juventusLogo, score: 2, scorers: [{ name: "Freddy Manrique", goals: 1 }, { name: "Jhonatan Flores", goals: 1 }] },
    awayTeam: { name: "Aviación", logo: aviacionLogo, score: 1, scorers: [{ name: "Jesús Mendoza", goals: 1 }] },
  },
  {
    homeTeam: { name: "FRM", logo: frmLogo, score: 1, scorers: [{ name: "Eduardo Rodríguez", goals: 1 }] },
    awayTeam: { name: "Ágape", logo: agapeLogo, score: 1, scorers: [{ name: "Ronmel Briceño", goals: 1 }] },
  },
  {
    homeTeam: { name: "Pepitos Point", logo: pepitosLogo, score: 2, scorers: [{ name: "Miguel Landaeta", goals: 1 }, { name: "Héctor González", goals: 1 }] },
    awayTeam: { name: "Chelsea", logo: chelseaLogo, score: 1, scorers: [{ name: "Eduardo Valdés", goals: 1 }] },
  },
  {
    homeTeam: { name: "Golazo", logo: golazoLogo, score: 0, scorers: [] },
    awayTeam: { name: "Real Maracay", logo: realMaracayLogo, score: 1, scorers: [{ name: "Daniel Olvera", goals: 1 }] },
  },
];

// Jornada 4
const jornada4Data = [
  {
    homeTeam: {
      name: "Real Maracay",
      logo: realMaracayLogo,
      score: 3,
      scorers: [
        { name: "Jackson Mijares", goals: 1 },
        { name: "Pedro Cuellar", goals: 1 },
        { name: "Adrian Bolivar", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Casa Italia",
      logo: cimLogo,
      score: 0,
      scorers: [],
    },
  },
  {
    homeTeam: {
      name: "Chelsea",
      logo: chelseaLogo,
      score: 2,
      scorers: [
        { name: "Deibi Infante", goals: 1 },
        { name: "Miguel Garcia", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Ágape",
      logo: agapeLogo,
      score: 2,
      scorers: [
        { name: "Yovanni de la Rosa", goals: 1 },
        { name: "Franklin Diaz", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Juventus",
      logo: juventusLogo,
      score: 5,
      scorers: [
        { name: "Freddy Manrique", goals: 2 },
        { name: "Rattia García", goals: 2 },
        { name: "Jhonatan Flores", goals: 1 },
      ],
    },
    awayTeam: {
      name: "FRM",
      logo: frmLogo,
      score: 1,
      scorers: [{ name: "Jose Fernández", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "Aviación",
      logo: aviacionLogo,
      score: 2,
      scorers: [
        { name: "Jose Castro", goals: 1 },
        { name: "Joexander Tovar", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Consorcio",
      logo: sanIgnacioLogo,
      score: 2,
      scorers: [
        { name: "Cristian Alarcón", goals: 1 },
        { name: "Joseph Fun", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Golazo",
      logo: golazoLogo,
      score: 3,
      scorers: [
        { name: "Erick Briceño", goals: 2 },
        { name: "Gabriel Segovia", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Pepitos Point",
      logo: pepitosLogo,
      score: 0,
      scorers: [],
    },
  },
];

// Jornada 2
const jornada2Data = [
  {
    homeTeam: {
      name: "Agape",
      logo: agapeLogo,
      score: 2,
      scorers: [{ name: "Wencer Gómez", goals: 2 }],
    },
    awayTeam: {
      name: "Casa Italia",
      logo: cimLogo,
      score: 1,
      scorers: [{ name: "Hernán Rico", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "Aviación",
      logo: aviacionLogo,
      score: 2,
      scorers: [
        { name: "Joexander Tovar", goals: 1 },
        { name: "José Hernández", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Real Maracay",
      logo: realMaracayLogo,
      score: 4,
      scorers: [
        { name: "Ramón Ruiz", goals: 2 },
        { name: "Osmel Franco", goals: 1 },
        { name: "Pedro Cuellar", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "FRM",
      logo: frmLogo,
      score: 2,
      scorers: [
        { name: "Rogelio", goals: 1 },
        { name: "Luis Basulto", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Chelsea",
      logo: chelseaLogo,
      score: 3,
      scorers: [
        { name: "Deibi Infante", goals: 1 },
        { name: "Jolfred Alexander", goals: 1 },
        { name: "Carlos Castro", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Golazo",
      logo: golazoLogo,
      score: 4,
      scorers: [
        { name: "Armando Serrano", goals: 1 },
        { name: "Jean Perozo", goals: 1 },
        { name: "Raúl Gómez", goals: 1 },
        { name: "Erick Briceño", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Juventus",
      logo: juventusLogo,
      score: 1,
      scorers: [{ name: "Freddy Manrrique", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "Pepitos Point",
      logo: pepitosLogo,
      score: 5,
      scorers: [
        { name: "Pablo Bernal", goals: 2 },
        { name: "Elio Barrios", goals: 1 },
        { name: "Andrés Parra", goals: 1 },
        { name: "Miguel Landaeta", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Consorcio",
      logo: sanIgnacioLogo,
      score: 1,
      scorers: [{ name: "Pablo Meligon", goals: 1 }],
    },
  },
];

// Jornada 8
const jornada8Data = [
  {
    homeTeam: {
      name: "Casa Italia",
      logo: cimLogo,
      score: 3,
      scorers: [
        { name: "Joe Molina", goals: 2 },
        { name: "Fernando Leal", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Chelsea",
      logo: chelseaLogo,
      score: 2,
      scorers: [
        { name: "Deibi Infante", goals: 1 },
        { name: "Marco Fatoni", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Golazo",
      logo: golazoLogo,
      score: 3,
      scorers: [
        { name: "Erick Briceño", goals: 1 },
        { name: "Roberto Di Prieto", goals: 1 },
        { name: "Armando Serrano", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Aviación",
      logo: aviacionLogo,
      score: 1,
      scorers: [{ name: "Rody Gómez", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "FRM",
      logo: frmLogo,
      score: 1,
      scorers: [{ name: "Morillo", goals: 1 }],
    },
    awayTeam: {
      name: "Consorcio",
      logo: sanIgnacioLogo,
      score: 3,
      scorers: [
        { name: "Cristina Alarcon", goals: 1 },
        { name: "Joseph Fun", goals: 1 },
        { name: "Lisandro Chirino", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Juventus",
      logo: juventusLogo,
      score: 0,
      scorers: [],
    },
    awayTeam: {
      name: "Real Maracay",
      logo: realMaracayLogo,
      score: 4,
      scorers: [
        { name: "Osmel Franco", goals: 2 },
        { name: "Franzua Cardona", goals: 1 },
        { name: "Yose Betancourt", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Ágape",
      logo: agapeLogo,
      score: 0,
      scorers: [],
    },
    awayTeam: {
      name: "Pepitos Point",
      logo: pepitosLogo,
      score: 0,
      scorers: [],
    },
  },
];

// Jornada 9
const jornada9Data = [
  {
    homeTeam: {
      name: "Casa Italia",
      logo: cimLogo,
      score: 1,
      scorers: [{ name: "Edison Segovia", goals: 1 }],
    },
    awayTeam: {
      name: "Golazo",
      logo: golazoLogo,
      score: 1,
      scorers: [{ name: "Erick Briceño", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "Juventus",
      logo: juventusLogo,
      score: 0,
      scorers: [],
    },
    awayTeam: {
      name: "Consorcio",
      logo: sanIgnacioLogo,
      score: 1,
      scorers: [{ name: "Francisco Salcedo", goals: 1 }],
    },
  },
  {
    homeTeam: {
      name: "FRM",
      logo: frmLogo,
      score: 0,
      scorers: [],
    },
    awayTeam: {
      name: "Pepitos Point",
      logo: pepitosLogo,
      score: 5,
      scorers: [
        { name: "Miguel Landaeta", goals: 2 },
        { name: "Andrés Parra", goals: 1 },
        { name: "Elio Barrios", goals: 1 },
        { name: "Gustavo Estrada", goals: 1 },
      ],
    },
  },
  {
    homeTeam: {
      name: "Real Maracay",
      logo: realMaracayLogo,
      score: 3,
      scorers: [
        { name: "Pedro Cuellar", goals: 2 },
        { name: "Ramón Ruiz", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Chelsea",
      logo: chelseaLogo,
      score: 2,
      scorers: [{ name: "Deibi Infante", goals: 2 }],
    },
  },
  {
    homeTeam: {
      name: "Ágape",
      logo: agapeLogo,
      score: 2,
      scorers: [
        { name: "Wencer Gómez", goals: 1 },
        { name: "Lewis Arciniega", goals: 1 },
      ],
    },
    awayTeam: {
      name: "Aviación",
      logo: aviacionLogo,
      score: 1,
      scorers: [{ name: "Joexander Tovar", goals: 1 }],
    },
  },
];

interface JornadaSectionProps {
  jornada: number;
  matches: typeof jornada1Data;
  partidos: number;
}

const JornadaSection = ({ jornada, matches, partidos }: JornadaSectionProps) => {
  return (
    <div className="mb-16 last:mb-0">
      {/* Jornada Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5 mb-4">
          <Calendar className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">
            {jornada === -1 ? "Cuartos de Final" : jornada === 0 ? "Fecha Pendiente" : `Fecha ${jornada}`}
          </span>
        </div>
        <p className="text-muted-foreground text-sm">
          {partidos} partidos jugados
        </p>
      </div>

      {/* Match Cards Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
        {matches.map((match, index) => (
          <MatchCard
            key={index}
            homeTeam={match.homeTeam}
            awayTeam={match.awayTeam}
            delay={index * 100}
          />
        ))}
      </div>
    </div>
  );
};

// Cuartos de Final
const cuartosData = [
  {
    homeTeam: { name: "Pepitos Point", logo: pepitosLogo, score: 0, scorers: [] },
    awayTeam: { name: "Casa Italia", logo: cimLogo, score: 2, scorers: [{ name: "Edinson Segovia", goals: 1 }, { name: "Jorge Villegas", goals: 1 }] },
  },
  {
    homeTeam: { name: "Consorcio", logo: sanIgnacioLogo, score: 0, scorers: [] },
    awayTeam: { name: "Ágape", logo: agapeLogo, score: 1, scorers: [{ name: "Gerald Romero", goals: 1 }] },
  },
  {
    homeTeam: { name: "Golazo", logo: golazoLogo, score: 1, scorers: [{ name: "Diamante Castro", goals: 1 }] },
    awayTeam: { name: "Chelsea", logo: chelseaLogo, score: 0, scorers: [] },
  },
  {
    homeTeam: { name: "Real Maracay", logo: realMaracayLogo, score: 2, scorers: [{ name: "Jackson Mijares", goals: 2 }] },
    awayTeam: { name: "Juventus", logo: juventusLogo, score: 0, scorers: [] },
  },
];

const ResultsSection = () => {
  return (
    <section id="resultados" className="py-16 md:py-24 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Resultados
          </h2>
          <p className="text-muted-foreground mt-2">
            Todos los partidos del torneo
          </p>
        </div>

        {/* Cuartos de Final */}
        <JornadaSection jornada={-1} matches={cuartosData} partidos={4} />

        {/* Jornada 9 */}
        <JornadaSection jornada={9} matches={jornada9Data} partidos={5} />

        {/* Jornada 8 */}
        <JornadaSection jornada={8} matches={jornada8Data} partidos={6} />

        {/* Jornada 7 */}
        <JornadaSection jornada={7} matches={jornada7Data} partidos={5} />

        {/* Jornada 6 */}
        <JornadaSection jornada={6} matches={jornada6Data} partidos={5} />

        {/* Jornada Pendiente (Reprogramada) */}
        <JornadaSection jornada={0} matches={jornadaPendienteData} partidos={2} />

        {/* Jornada 5 */}
        <JornadaSection jornada={5} matches={jornada5Data} partidos={5} />

        {/* Jornada 4 */}
        <JornadaSection jornada={4} matches={jornada4Data} partidos={5} />

        {/* Jornada 3 */}
        <JornadaSection jornada={3} matches={jornada3Data} partidos={5} />

        {/* Jornada 2 */}
        <JornadaSection jornada={2} matches={jornada2Data} partidos={5} />
        
        {/* Jornada 1 */}
        <JornadaSection jornada={1} matches={jornada1Data} partidos={3} />
      </div>
    </section>
  );
};

export default ResultsSection;
