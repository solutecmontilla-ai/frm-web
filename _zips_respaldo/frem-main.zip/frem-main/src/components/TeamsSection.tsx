import aviacionLogo from "@/assets/teams/aviacion-fc.png";
import agapeLogo from "@/assets/teams/agape-fc.png";
import juventusLogo from "@/assets/teams/juventus-ng.png";
import frmLogo from "@/assets/teams/frm.png";
import sanIgnacioLogo from "@/assets/teams/san-ignacio-fc.png";
import pepitosLogo from "@/assets/teams/pepitos-el-point.png";
import golazoLogo from "@/assets/teams/golazo-fc.png";
import chelseaLogo from "@/assets/teams/chelsea-fc.png";
import realMaracayLogo from "@/assets/teams/real-maracay-fc.png";
import cimLogo from "@/assets/teams/cim.png";

const teams = [
  { name: "Aviación FC", logo: aviacionLogo },
  { name: "Agape FC", logo: agapeLogo },
  { name: "Juventus NG", logo: juventusLogo },
  { name: "Fundación Rogelio Montaño", logo: frmLogo },
  { name: "San Ignacio F.C.", logo: sanIgnacioLogo },
  { name: "Pepitos El Point", logo: pepitosLogo },
  { name: "Golazo FC", logo: golazoLogo },
  { name: "Chelsea FC", logo: chelseaLogo },
  { name: "Real Maracay F.C.", logo: realMaracayLogo },
  { name: "C.I.M.", logo: cimLogo },
];

const TeamsSection = () => {
  return (
    <section id="equipos" className="py-16 md:py-24 bg-gradient-to-b from-card to-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 bg-primary/20 text-primary rounded-full text-sm font-medium mb-4 tracking-wider">
            NOVENA EDICIÓN
          </span>
          <h2 className="text-3xl md:text-5xl font-display text-foreground mb-4">
            Equipos <span className="text-gradient-gold">Participantes</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            10 equipos compiten por la gloria en la novena edición de la Liga FRM
          </p>
        </div>

        {/* Teams Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 md:gap-8">
          {teams.map((team, index) => (
            <div
              key={team.name}
              className="group relative flex flex-col items-center animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Card */}
              <div className="relative w-full aspect-square bg-gradient-card rounded-xl border border-border/50 p-4 md:p-6 transition-all duration-300 group-hover:border-primary/50 group-hover:shadow-glow group-hover:-translate-y-2">
                {/* Glow effect */}
                <div className="absolute inset-0 rounded-xl bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Logo container with transparent background handling */}
                <div className="relative w-full h-full flex items-center justify-center">
                  <img
                    src={team.logo}
                    alt={`Logo de ${team.name}`}
                    className="max-w-full max-h-full object-contain drop-shadow-lg transition-transform duration-300 group-hover:scale-110"
                    style={{ 
                      filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.3))',
                      mixBlendMode: 'normal'
                    }}
                  />
                </div>
              </div>

              {/* Team name */}
              <h3 className="mt-4 text-sm md:text-base font-medium text-center text-foreground/90 group-hover:text-primary transition-colors duration-300 line-clamp-2">
                {team.name}
              </h3>
            </div>
          ))}
        </div>

        {/* Bottom accent */}
        <div className="mt-16 flex justify-center">
          <div className="h-1 w-32 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default TeamsSection;
